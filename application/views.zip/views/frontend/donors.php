<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<style>
    	.row{
		    margin-top:40px;
		    padding: 0 10px;
		}
		.clickable{
		    cursor: pointer;   
		}

		.panel-heading div {
			margin-top: -18px;
			font-size: 15px;
		}
		.panel-heading div span{
			margin-left:5px;
		}
		.panel-body{
			display: none;
		}
</style>

<div class="container">
    <h1>Click the filter icon <small>(<i class="glyphicon glyphicon-filter"></i>)</small></h1>
    	<div class="row">
			<div class="col-md-6" style="margin-left: 260px;">
				<div class="panel panel-primary">
					<div class="panel-heading" style="background:maroon;">
						<h3 class="panel-title">Donors</h3>
						<div class="pull-right">
							<span class="clickable filter" data-toggle="tooltip" title="Toggle table filter" data-container="body">
								<i class="glyphicon glyphicon-filter"></i>
							</span>
						</div>
					</div>
					<div class="panel-body">
						<input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
					</div>

					<table class="table table-hover" id="dev-table">
						<thead>
	
							<tr>
							
								<th>Donor Name</th>
								<th>Donor Gender</th>
								<th>Donor Age</th>
                				<th>Donor Addiction</th>
							</tr>
						</thead>
						<tbody>
					
						<?php foreach($data as $row) { ?>
							<tr>
								<td><?php echo $row->donor_firstName;?> <?php echo $row->donor_lastName;?> </td>
								<td><?php echo $row->donor_gender;?></td>
								<td><?php echo $row->donor_age;?></td>
								<td><?php echo $row->donor_addiction;?></td>
							</tr>
						<?php } ?>
				
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-md-6">
				
			</div>
		</div>
	</div>