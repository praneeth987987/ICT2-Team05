<!DOCTYPE html>
<div class="main">
  <div class="main-inner">
    <div class="container">
      <div class="row" style="margin-left:300px">
	   <div class="span6">
  <div class="widget widget-nopad">
            <div class="widget-header"> <i class="icon-list-alt"></i>
              <h3> Findblood Stats</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <div class="widget big-stats-container">
                <div class="widget-content">
                    <div id="big_stats" class="cf">
                    <div class="stat"> <i class="">Donors</i> <span class="value"><?php echo $donors; ?></span> </div>
                    <!-- .stat -->
                     
                    <div class="stat"> <i class="">Events</i> <span class="value"><?php echo $events; ?></span> </div>
                    <!-- .stat -->
                    
                    <div class="stat"> <i class="">Contacts</i> <span class="value"><?php echo $messages; ?></span> </div>
                    <!-- .stat --> 
                  </div>
                </div>
                <!-- /widget-content --> 
                
              </div>
            </div>
          </div>
		     </div> 
			    </div>
				   </div>   
				   </div>

