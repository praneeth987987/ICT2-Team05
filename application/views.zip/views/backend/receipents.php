 <div class="widget widget-table action-table">
            <div class="widget-header"> <i class="icon-th-list"></i>
              <h3>List of Receipents</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <table class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th> Receipent Name </th>
					<th> Contact Number </th>
					<th> Address </th>
					<th> Blood Group </th>
					<th> Addiction </th>
                    <th> Medical Report </th>
                    <th class="td-actions">Actions </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
            
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                 </tr>
				  <tr>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
            
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                 </tr> <tr>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
            
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                 </tr> <tr>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
            
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                 </tr> <tr>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
					<td> .......... </td>
            
                    <td class="td-actions"><a href="javascript:;" class="btn btn-small btn-success"><i class="btn-icon-only icon-ok"> </i></a><a href="javascript:;" class="btn btn-danger btn-small"><i class="btn-icon-only icon-remove"> </i></a></td>
                 </tr>
                  
                
                </tbody>
              </table>
            </div>
            <!-- /widget-content --> 
          </div>