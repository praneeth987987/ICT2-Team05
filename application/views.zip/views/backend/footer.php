<!DOCTYPE html>
<!-- /extra -->
<div class="footer">
  <div class="footer-inner">
    <div class="container">
      <div class="row">
        <div class="span12"> &copy; 2019 <a href="#">FindBlood Admin</a>. </div>
        <!-- /span12 --> 
      </div>
      <!-- /row --> 
    </div>
    <!-- /container --> 
  </div>
  <!-- /footer-inner --> 
</div>
<!-- /footer --> 
<!-- Le javascript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="<?php echo base_url();?>BackAssets/js/jquery-1.7.2.min.js"></script> 
<script src="<?php echo base_url();?>BackAssets/js/excanvas.min.js"></script> 
<script src="<?php echo base_url();?>BackAssets/js/chart.min.js" type="text/javascript"></script> 
<script src="<?php echo base_url();?>BackAssets/js/bootstrap.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo base_url();?>BackAssets/js/full-calendar/fullcalendar.min.js"></script>
 
<script src="<?php echo base_url();?>BackAssets/js/base.js"></script> 
</body>
</html>
